Este es un ejemplo básico de una aplicación Flask lista para desplegarse en Render.
